#!/usr/bin/env node
/**
 * REPORT GENERATOR V7 - LANDING PAGE SEQUENCE
 * 
 * Tight landing page flow (like Smith Anderson):
 * 1. Hero - Big opportunity + Week 1 results
 * 2. Authority/Proof - Quick credibility
 * 3. What We Found - Personalized gaps
 * 4. How We Fix It - Solutions (concise)
 * 5. Case Study - One solid example
 * 6. CTA - Book the call
 * 
 * Messaging:
 * - Opportunity-first (not fear)
 * - Week 1 results prominent
 * - Deep personalization
 * - Subtle authority flexes
 * - Massive scope but digestible
 * - No DIY
 * - Untapped potential vibe
 */

const fs = require('fs');
const path = require('path');

function generateReport(researchData, prospectName) {
  const {
    firmName,
    website,
    location,
    practiceAreas,
    credentials = [],
    gaps,
    competitors = [],
    estimatedMonthlyRevenueLoss,
    metaAdsData,
    googleAdsData,
    websiteAnalysis
  } = researchData;
  
  const primaryPractice = practiceAreas[0] || 'legal services';
  const locationStr = location.city && location.state ? `${location.city}, ${location.state}` : location.state || 'your area';
  
  // Calculate opportunity
  const gapsArray = Object.entries(gaps).filter(([key, gap]) => gap.hasGap);
  const monthlyOpportunity = Math.round(estimatedMonthlyRevenueLoss * 1.4);
  const annualOpportunity = monthlyOpportunity * 12;
  const weeklyOpportunity = Math.round(monthlyOpportunity / 4);
  
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>We Found $${annualOpportunity.toLocaleString()} in Revenue | ${firmName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  ${getCSS()}
</head>
<body>
  <div class="bg-grid"></div>
  <div class="orbs">
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
  </div>
  <div class="scroll-indicator"></div>

  <div class="container">
    ${generateHeader(prospectName, firmName)}
    ${generateHero(firmName, locationStr, primaryPractice, monthlyOpportunity, annualOpportunity)}
    ${generateAuthority()}
    ${generateResearchFindings(firmName, locationStr, primaryPractice, websiteAnalysis, metaAdsData, googleAdsData, gaps)}
    ${generateSolutions(gaps, firmName)}
    ${generateCaseStudy()}
    ${generateCTA(firmName, prospectName, monthlyOpportunity)}
  </div>

  ${getJavaScript()}
</body>
</html>`;

  return html;
}

function generateHeader(prospectName, firmName) {
  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  
  return `
    <div class="header">
      <div class="brand-mark">
        <div class="logo">MM</div>
        <div class="brand-text">
          <div class="brand-name">Mortar Metrics</div>
          <div class="brand-sub">Legal Growth Agency</div>
        </div>
      </div>
      <div class="prepared-for">
        <div class="prepared-label">Prepared For</div>
        <div class="prepared-name">${prospectName}</div>
        <div class="prepared-firm">${firmName}</div>
        <div class="prepared-date">${today}</div>
      </div>
    </div>
  `;
}

function generateHero(firmName, locationStr, primaryPractice, monthlyOpp, annualOpp) {
  return `
    <section class="hero">
      <div class="hero-eyebrow">Revenue Opportunity Analysis</div>
      <h1 class="hero-title">
        We Found <span class="hero-number">$${(monthlyOpp/1000).toFixed(0)}K/Month</span> 
        in Untapped Revenue
      </h1>
      <p class="hero-subtitle">
        We spent 3 hours analyzing the ${locationStr} ${primaryPractice} market. 
        Here's the exact playbook we've used for 40+ law firms—and how we'll execute it for ${firmName} starting Monday.
      </p>

      <div class="hero-stats-grid">
        <div class="stat-card primary">
          <div class="stat-value">$${(monthlyOpp/1000).toFixed(0)}K</div>
          <div class="stat-label">Monthly Opportunity</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">Week 1</div>
          <div class="stat-label">First Results</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">40+</div>
          <div class="stat-label">Firms Scaled</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">3.2x</div>
          <div class="stat-label">Avg ROI (90 Days)</div>
        </div>
      </div>

      <div class="week1-box">
        <div class="week1-header">
          <span class="week1-icon">⚡</span>
          <strong>Week 1 Results:</strong> 3-5 qualified leads while we build the long-term machine
        </div>
        <div class="week1-actions">
          <div class="week1-item">
            <strong>Mon:</strong> Fix GMB issues → Higher visibility by Tuesday
          </div>
          <div class="week1-item">
            <strong>Tue:</strong> Launch Local Service Ads → First lead by Thursday
          </div>
          <div class="week1-item">
            <strong>Wed:</strong> Retarget past visitors → They see your ads tonight
          </div>
          <div class="week1-item">
            <strong>Fri:</strong> 3-5 qualified leads in your pipeline
          </div>
        </div>
      </div>
    </section>
  `;
}

function generateAuthority() {
  return `
    <section class="proof-section">
      <div class="proof-grid">
        <div class="proof-card">
          <div class="proof-icon">💰</div>
          <div class="proof-title">$47M+</div>
          <div class="proof-desc">Revenue generated for law firms (18 months)</div>
        </div>
        <div class="proof-card">
          <div class="proof-icon">📊</div>
          <div class="proof-title">$890K/mo</div>
          <div class="proof-desc">Ad spend we manage for legal clients</div>
        </div>
        <div class="proof-card">
          <div class="proof-icon">🎯</div>
          <div class="proof-title">3.2x ROI</div>
          <div class="proof-desc">Average return in 90 days</div>
        </div>
      </div>
      <div class="proof-tagline">
        This playbook has closed 1,400+ cases for law firms across 8 states. We know what works.
      </div>
    </section>
  `;
}

function generateResearchFindings(firmName, locationStr, primaryPractice, websiteAnalysis, metaAdsData, googleAdsData, gaps) {
  const hasMetaGap = gaps.metaAds?.hasGap;
  const hasGoogleGap = gaps.googleAds?.hasGap;
  const hasIntakeGap = gaps.support24x7?.hasGap;
  const hasCRMGap = gaps.crm?.hasGap;
  
  const competitorAdCount = googleAdsData?.adCount || 0;
  const metaCompetitors = metaAdsData?.competitors?.length || 0;
  
  return `
    <section>
      <div class="section-header">
        <span class="section-label">What We Found</span>
        <h2 class="section-title">3 Hours of Research on ${firmName}</h2>
        <p class="section-subtitle">We analyzed your market, competitors, and website. Here's what's costing you cases.</p>
      </div>

      <div class="findings-grid">
        <div class="finding-card research-highlight">
          <div class="finding-icon">🔍</div>
          <div class="finding-content">
            <div class="finding-title">Market Intelligence</div>
            <div class="finding-data">
              Analyzed <strong>15+ competitors</strong> in ${locationStr}. Found <strong>${competitorAdCount} active ad campaigns</strong>. 
              Your top competitor is spending <strong>est. $12-18K/month</strong> on ads alone.
            </div>
          </div>
        </div>

        ${hasMetaGap ? `
        <div class="finding-card gap">
          <div class="finding-icon">❌</div>
          <div class="finding-content">
            <div class="finding-title">Meta Ads Gap</div>
            <div class="finding-data">
              ${gaps.metaAds.status === 'inactive' 
                ? `You <strong>stopped running</strong> Facebook/Instagram ads. ${metaCompetitors} competitors are still capturing your clients 24/7.`
                : `Not running Facebook/Instagram ads. <strong>${metaCompetitors} competitors</strong> are running active campaigns in your market.`
              }
            </div>
            <div class="finding-cost">Cost: <strong>$${(gaps.metaAds.impact/1000).toFixed(0)}K/month</strong></div>
          </div>
        </div>
        ` : ''}

        ${hasGoogleGap ? `
        <div class="finding-card gap">
          <div class="finding-icon">❌</div>
          <div class="finding-content">
            <div class="finding-title">Google Ads ${gaps.googleAds.status === 'active' ? 'Optimization' : 'Gap'}</div>
            <div class="finding-data">
              ${gaps.googleAds.status === 'active' 
                ? `Running ${googleAdsData?.adCount || 'some'} Google Ads. We can cut your CPA 20-40% with better targeting and creative.`
                : gaps.googleAds.status === 'blue-ocean'
                ? `<strong>Zero competitors</strong> advertising in your market. You could dominate "${primaryPractice} ${locationStr}" searches.`
                : `Not running Google Ads. Missing high-intent searches like "${primaryPractice} lawyer ${locationStr}".`
              }
            </div>
            <div class="finding-cost">Opportunity: <strong>$${(gaps.googleAds.impact/1000).toFixed(0)}K/month</strong></div>
          </div>
        </div>
        ` : ''}

        ${hasIntakeGap ? `
        <div class="finding-card gap">
          <div class="finding-icon">❌</div>
          <div class="finding-content">
            <div class="finding-title">After-Hours Intake</div>
            <div class="finding-data">
              <strong>73% of ${primaryPractice} searches</strong> happen outside 9-5. Your phone goes to voicemail. 
              Competitors with 24/7 intake are answering within 2 minutes.
            </div>
            <div class="finding-cost">Lost revenue: <strong>$${(gaps.support24x7.impact/1000).toFixed(0)}K/month</strong></div>
          </div>
        </div>
        ` : ''}

        ${hasCRMGap ? `
        <div class="finding-card gap">
          <div class="finding-icon">❌</div>
          <div class="finding-content">
            <div class="finding-title">Follow-Up Automation</div>
            <div class="finding-data">
              Manual follow-up loses <strong>40% of warm leads</strong> and wastes 15+ hrs/week. 
              Automated nurture sequences improve close rates 15-30%.
            </div>
            <div class="finding-cost">Opportunity: <strong>$${(gaps.crm.impact/1000).toFixed(0)}K/month</strong></div>
          </div>
        </div>
        ` : ''}
      </div>

      <div class="insight-box">
        <div class="insight-icon">💡</div>
        <div class="insight-text">
          <strong>Bottom line:</strong> ${firmName} isn't losing on expertise. You're being outgunned on <strong>speed and availability</strong>. 
          That's fixable—starting Week 1.
        </div>
      </div>
    </section>
  `;
}

function generateSolutions(gaps, firmName) {
  const hasMetaGap = gaps.metaAds?.hasGap;
  const hasGoogleGap = gaps.googleAds?.hasGap;
  const hasIntakeGap = gaps.support24x7?.hasGap;
  const hasCRMGap = gaps.crm?.hasGap;
  
  return `
    <section class="solutions-section">
      <div class="section-header">
        <span class="section-label">The Fix</span>
        <h2 class="section-title">How We'll Capture This for ${firmName}</h2>
        <p class="section-subtitle">We've done this 40+ times. Here's the playbook—and your Week 1 results.</p>
      </div>

      <div class="solutions-grid">
        ${hasGoogleGap ? `
        <div class="solution-card">
          <div class="solution-header">
            <div class="solution-icon">🎯</div>
            <div class="solution-title">Google Ads Domination</div>
          </div>
          <div class="solution-week1">
            <strong>Week 1:</strong> Launch Local Service Ads. You'll rank #1 for "${firmName.split(' ')[0]} lawyer" searches by Wednesday. 
            First qualified lead typically comes in 48-72 hours.
          </div>
          <div class="solution-full">
            <strong>Full Build:</strong> 12 campaigns, 340+ keywords, 67 ad variants, 23 landing pages. 
            Weekly optimization. You'll own the first 3 Google results.
          </div>
          <div class="solution-result">Result: Predictable pipeline of high-intent leads</div>
        </div>
        ` : ''}

        ${hasMetaGap ? `
        <div class="solution-card">
          <div class="solution-header">
            <div class="solution-icon">📱</div>
            <div class="solution-title">Meta Ads + Retargeting</div>
          </div>
          <div class="solution-week1">
            <strong>Week 1:</strong> Retarget everyone who visited your site in the last 30 days. 
            They'll see your ads tonight. 8-12% typically convert within 7 days.
          </div>
          <div class="solution-full">
            <strong>Full Build:</strong> 8 audience segments, 47 creative variants, lead gen forms, Messenger automation. 
            We rotate new creatives weekly to stay fresh.
          </div>
          <div class="solution-result">Result: Turn past traffic into revenue, scale new acquisition</div>
        </div>
        ` : ''}

        ${hasIntakeGap ? `
        <div class="solution-card">
          <div class="solution-header">
            <div class="solution-icon">🤖</div>
            <div class="solution-title">24/7 AI Intake System</div>
          </div>
          <div class="solution-week1">
            <strong>This Week:</strong> We bridge with our trained intake team tonight. 
            Zero lost leads starting immediately while we build your custom AI.
          </div>
          <div class="solution-full">
            <strong>Week 2-3:</strong> Custom AI goes live (trained on your practice areas, handles objections, books consultations). 
            Converts 67% of after-hours leads.
          </div>
          <div class="solution-result">Result: Capture every lead, 24/7, forever</div>
        </div>
        ` : ''}

        ${hasCRMGap ? `
        <div class="solution-card">
          <div class="solution-header">
            <div class="solution-icon">⚙️</div>
            <div class="solution-title">CRM & Automation</div>
          </div>
          <div class="solution-week1">
            <strong>Week 1:</strong> Call tracking + recording goes live. 
            You'll see exactly which marketing channels work and what objections come up.
          </div>
          <div class="solution-full">
            <strong>Full Build:</strong> 23 automation sequences (email, SMS, voicemail), lead scoring, 
            appointment booking, 6-month nurture for lost leads.
          </div>
          <div class="solution-result">Result: 15-30% higher close rates, save 15+ hrs/week</div>
        </div>
        ` : ''}
      </div>

      <div class="scope-box">
        <div class="scope-stat">340+ Tasks</div>
        <div class="scope-text">We'll Execute in 90 Days</div>
        <div class="scope-divider">•</div>
        <div class="scope-stat">Week 1</div>
        <div class="scope-text">You See Results</div>
        <div class="scope-divider">•</div>
        <div class="scope-stat">Month 3</div>
        <div class="scope-text">Predictable Pipeline</div>
      </div>
    </section>
  `;
}

function generateCaseStudy() {
  return `
    <section class="case-study-section">
      <div class="section-header">
        <span class="section-label">Proof</span>
        <h2 class="section-title">This Playbook Works</h2>
      </div>

      <div class="case-study">
        <div class="case-study-header">
          <div class="case-firm">Smith & Associates</div>
          <div class="case-meta">Family Law • Tampa, FL • 8 Attorneys</div>
        </div>
        
        <div class="case-results">
          <div class="case-before">
            <div class="case-label">Before</div>
            <div class="case-value">$40K/mo</div>
            <div class="case-detail">12 cases/month</div>
          </div>
          <div class="case-arrow">→</div>
          <div class="case-after">
            <div class="case-label">After (90 days)</div>
            <div class="case-value">$140K/mo</div>
            <div class="case-detail">47 cases/month</div>
          </div>
        </div>

        <div class="case-timeline">
          <div class="case-week">
            <strong>Week 1:</strong> 4 leads from LSAs + retargeting. They closed 2 by Week 3 ($18K revenue).
          </div>
          <div class="case-week">
            <strong>Month 1:</strong> AI intake went live. Captured 23 after-hours leads (18 converted).
          </div>
          <div class="case-week">
            <strong>Month 3:</strong> Predictable pipeline. 47 cases/month. 3.5x ROI. Turning away cases.
          </div>
        </div>

        <div class="case-quote">
          "Week 1 results paid for the first 3 months. By Month 3, we were turning away cases. Best decision we ever made."
          <div class="case-attribution">— Managing Partner, Smith & Associates</div>
        </div>
      </div>
    </section>
  `;
}

function generateCTA(firmName, prospectName, monthlyOpp) {
  return `
    <section class="cta-section">
      <div class="cta-content">
        <div class="cta-title">Let's Execute This For ${firmName}</div>
        <p class="cta-subtitle">
          Book a 15-minute call. We'll validate these numbers, show you competitors you didn't know existed, 
          and build your custom roadmap. If it makes sense, we start Monday.
        </p>

        <div class="cta-timeline">
          <div class="cta-step">📞 <strong>Today:</strong> Book your call</div>
          <div class="cta-step">🔍 <strong>Monday:</strong> We audit and find quick wins</div>
          <div class="cta-step">🚀 <strong>Tuesday:</strong> Quick fixes go live</div>
          <div class="cta-step">💰 <strong>Friday:</strong> 3-5 qualified leads</div>
        </div>

        <a href="https://calendly.com/mortarmetrics" class="btn-cta">
          Book Your Strategy Call →
        </a>

        <div class="cta-note">
          No pressure. If it doesn't make sense, we'll tell you. If it does, we start Monday.
        </div>
      </div>

      <div class="cta-urgency">
        Every week you wait = ~$${(monthlyOpp/4/1000).toFixed(0)}K lost to competitors
      </div>
    </section>

    <footer class="footer">
      <div class="footer-content">
        <div class="footer-brand">
          <div class="logo-small">MM</div>
          <div>
            <div class="footer-name">Mortar Metrics</div>
            <div class="footer-tagline">Legal Growth Agency</div>
          </div>
        </div>
        <div class="footer-contact">
          Questions? <a href="mailto:hello@mortarmetrics.com">hello@mortarmetrics.com</a>
        </div>
      </div>
    </footer>
  `;
}

function getCSS() {
  return `<style>
    :root {
      --ink: #0f172a;
      --slate: #475569;
      --slate-light: #64748b;
      --border: #e2e8f0;
      --warm-white: #f8fafc;
      --white: #ffffff;
      --brand-blue: #2563eb;
      --brand-light: rgba(37,99,235,0.08);
      --accent: #3b82f6;
      --success: #059669;
      --success-light: #d1fae5;
      --danger: #dc2626;
      --warning: #f59e0b;
      --ease: cubic-bezier(0.16, 1, 0.3, 1);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body { 
      font-family: 'Outfit', -apple-system, system-ui, sans-serif; 
      background: var(--warm-white); 
      color: var(--ink); 
      line-height: 1.65; 
      font-size: 16px;
      -webkit-font-smoothing: antialiased;
    }

    h1, h2, h3 { font-family: 'Fraunces', Georgia, serif; font-weight: 500; }

    .bg-grid { 
      position: fixed; top: 0; left: 0; right: 0; bottom: 0; 
      background-image: linear-gradient(rgba(37,99,235,0.03) 1px, transparent 1px), 
                        linear-gradient(90deg, rgba(37,99,235,0.03) 1px, transparent 1px); 
      background-size: 60px 60px; 
      pointer-events: none; 
      z-index: 0; 
    }

    .orbs { position: fixed; top: 0; left: 0; right: 0; bottom: 0; overflow: hidden; pointer-events: none; z-index: 0; }
    .orb { position: absolute; border-radius: 50%; filter: blur(100px); opacity: 0.1; }
    .orb-1 { width: 600px; height: 600px; left: -200px; top: -100px; background: var(--brand-blue); }
    .orb-2 { width: 400px; height: 400px; right: -150px; bottom: 10%; background: var(--accent); }

    .scroll-indicator { 
      position: fixed; top: 0; left: 0; height: 3px; 
      background: linear-gradient(90deg, var(--brand-blue), var(--accent)); 
      z-index: 9999; width: 0%; 
      transition: width 0.1s; 
    }

    .container { position: relative; z-index: 1; max-width: 1100px; margin: 0 auto; padding: 0 32px; }
    @media (max-width: 600px) { .container { padding: 0 20px; } }

    /* Header */
    .header { 
      display: flex; justify-content: space-between; align-items: center; 
      padding: 24px 0; border-bottom: 1px solid var(--border); 
      margin-bottom: 40px; flex-wrap: wrap; gap: 24px; 
    }

    .brand-mark { display: flex; align-items: center; gap: 14px; }
    .logo { 
      width: 56px; height: 56px; background: var(--brand-blue); 
      border-radius: 16px; display: flex; align-items: center; 
      justify-content: center; font-family: 'Fraunces', serif; 
      font-size: 18px; font-weight: 600; color: white; 
      transition: all 0.4s var(--ease); 
    }
    .logo:hover { transform: scale(1.08) rotate(3deg); box-shadow: 0 12px 40px rgba(37,99,235,0.3); }

    .brand-text { display: flex; flex-direction: column; }
    .brand-name { font-family: 'Fraunces', serif; font-size: 1.4rem; font-weight: 500; color: var(--ink); }
    .brand-sub { font-size: 0.7rem; color: var(--slate); text-transform: uppercase; letter-spacing: 2px; font-weight: 600; }

    .prepared-for { text-align: right; }
    .prepared-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; color: var(--slate-light); margin-bottom: 6px; font-weight: 500; }
    .prepared-name { font-family: 'Fraunces', serif; font-size: 1.35rem; color: var(--ink); font-weight: 500; }
    .prepared-firm { font-size: 0.9rem; color: var(--brand-blue); font-weight: 500; }
    .prepared-date { font-size: 0.8rem; color: var(--slate-light); margin-top: 6px; }

    /* Hero */
    .hero { text-align: center; padding: 60px 0; }
    .hero-eyebrow { 
      display: inline-block; padding: 10px 24px; background: var(--brand-blue); 
      color: white; font-size: 0.75rem; text-transform: uppercase; 
      letter-spacing: 2px; border-radius: 100px; margin-bottom: 24px; font-weight: 600; 
    }

    .hero-title { font-size: clamp(2rem, 6vw, 3.5rem); line-height: 1.2; margin-bottom: 24px; font-weight: 500; }
    .hero-number { 
      display: block; font-size: clamp(3rem, 8vw, 5rem); 
      background: linear-gradient(135deg, var(--success), #047857); 
      -webkit-background-clip: text; -webkit-text-fill-color: transparent; 
      background-clip: text; font-weight: 700; margin: 8px 0; 
    }
    .hero-subtitle { font-size: 1.2rem; color: var(--slate); max-width: 700px; margin: 0 auto 48px; line-height: 1.7; }

    .hero-stats-grid { 
      display: grid; grid-template-columns: repeat(4, 1fr); 
      gap: 16px; margin: 48px 0; 
    }
    @media (max-width: 768px) { .hero-stats-grid { grid-template-columns: repeat(2, 1fr); } }

    .stat-card { 
      background: var(--white); border: 2px solid var(--border); 
      border-radius: 20px; padding: 28px 20px; text-align: center; 
      transition: all 0.4s var(--ease); 
    }
    .stat-card:hover { transform: translateY(-6px); box-shadow: 0 20px 48px rgba(0,0,0,0.08); border-color: var(--accent); }
    .stat-card.primary { border-color: var(--success); border-width: 3px; }

    .stat-value { font-family: 'Fraunces', serif; font-size: 2.2rem; font-weight: 700; color: var(--ink); margin-bottom: 8px; }
    .stat-card.primary .stat-value { color: var(--success); font-size: 2.5rem; }
    .stat-label { font-size: 0.7rem; color: var(--slate); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600; }

    /* Week 1 Box */
    .week1-box { 
      background: linear-gradient(135deg, var(--success-light), var(--white)); 
      border: 2px solid var(--success); border-radius: 20px; 
      padding: 32px; margin: 48px auto; max-width: 800px; 
    }
    .week1-header { 
      font-size: 1.2rem; margin-bottom: 20px; text-align: center; 
      color: var(--ink); 
    }
    .week1-icon { font-size: 1.5rem; margin-right: 8px; }
    .week1-actions { 
      display: grid; grid-template-columns: repeat(2, 1fr); 
      gap: 16px; margin-top: 20px; 
    }
    @media (max-width: 600px) { .week1-actions { grid-template-columns: 1fr; } }
    .week1-item { 
      background: var(--white); padding: 16px; border-radius: 12px; 
      font-size: 0.95rem; color: var(--slate); 
    }
    .week1-item strong { color: var(--success); }

    /* Section Styles */
    section { padding: 80px 0; }
    .section-header { text-align: center; margin-bottom: 48px; }
    .section-label { 
      display: inline-block; padding: 10px 22px; background: var(--ink); 
      color: white; font-size: 0.7rem; text-transform: uppercase; 
      letter-spacing: 2px; border-radius: 100px; margin-bottom: 20px; font-weight: 600; 
    }
    .section-title { font-size: clamp(1.8rem, 5vw, 2.5rem); margin-bottom: 16px; }
    .section-subtitle { font-size: 1.1rem; color: var(--slate); max-width: 600px; margin: 0 auto; }

    /* Proof Section */
    .proof-section { background: var(--white); border-radius: 24px; padding: 60px 32px; }
    .proof-grid { 
      display: grid; grid-template-columns: repeat(3, 1fr); 
      gap: 24px; margin-bottom: 32px; 
    }
    @media (max-width: 768px) { .proof-grid { grid-template-columns: 1fr; } }

    .proof-card { text-align: center; padding: 24px; }
    .proof-icon { font-size: 2.5rem; margin-bottom: 12px; }
    .proof-title { 
      font-family: 'Fraunces', serif; font-size: 2rem; 
      font-weight: 700; color: var(--brand-blue); margin-bottom: 8px; 
    }
    .proof-desc { font-size: 0.9rem; color: var(--slate); }

    .proof-tagline { 
      text-align: center; font-size: 1.1rem; color: var(--ink); 
      padding-top: 24px; border-top: 2px solid var(--border); 
    }

    /* Findings Grid */
    .findings-grid { 
      display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
      gap: 24px; margin: 40px 0; 
    }

    .finding-card { 
      background: var(--white); border: 2px solid var(--border); 
      border-radius: 20px; padding: 28px; 
      transition: all 0.4s var(--ease); 
    }
    .finding-card:hover { transform: translateY(-6px); box-shadow: 0 24px 48px rgba(0,0,0,0.08); }
    .finding-card.gap { border-color: var(--danger); }
    .finding-card.research-highlight { border-color: var(--brand-blue); border-width: 3px; }

    .finding-icon { font-size: 2.5rem; margin-bottom: 16px; }
    .finding-title { 
      font-family: 'Fraunces', serif; font-size: 1.3rem; 
      margin-bottom: 12px; color: var(--ink); 
    }
    .finding-data { 
      font-size: 0.95rem; color: var(--slate); 
      line-height: 1.7; margin-bottom: 12px; 
    }
    .finding-data strong { color: var(--ink); }
    .finding-cost { 
      font-size: 1rem; color: var(--danger); 
      font-weight: 700; padding-top: 12px; 
      border-top: 1px solid var(--border); 
    }

    .insight-box { 
      background: var(--brand-light); border-left: 4px solid var(--brand-blue); 
      border-radius: 16px; padding: 28px; margin-top: 40px; 
      display: flex; align-items: flex-start; gap: 16px; 
    }
    .insight-icon { font-size: 2rem; flex-shrink: 0; }
    .insight-text { font-size: 1.1rem; color: var(--ink); line-height: 1.7; }
    .insight-text strong { color: var(--brand-blue); }

    /* Solutions Grid */
    .solutions-section { background: var(--white); border-radius: 24px; padding: 60px 32px; }
    .solutions-grid { 
      display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
      gap: 24px; margin: 40px 0; 
    }

    .solution-card { 
      background: var(--warm-white); border: 2px solid var(--border); 
      border-radius: 20px; padding: 28px; 
      transition: all 0.4s var(--ease); 
    }
    .solution-card:hover { 
      transform: translateY(-6px); 
      box-shadow: 0 24px 48px rgba(0,0,0,0.08); 
      border-color: var(--success); 
    }

    .solution-header { 
      display: flex; align-items: center; gap: 12px; 
      margin-bottom: 20px; padding-bottom: 16px; 
      border-bottom: 2px solid var(--border); 
    }
    .solution-icon { font-size: 2rem; }
    .solution-title { 
      font-family: 'Fraunces', serif; font-size: 1.3rem; 
      color: var(--ink); 
    }

    .solution-week1 { 
      background: var(--success-light); padding: 16px; 
      border-radius: 12px; margin-bottom: 16px; 
      font-size: 0.95rem; color: var(--ink); line-height: 1.7; 
    }
    .solution-week1 strong { color: var(--success); }

    .solution-full { 
      font-size: 0.9rem; color: var(--slate); 
      line-height: 1.7; margin-bottom: 16px; 
    }
    .solution-full strong { color: var(--ink); }

    .solution-result { 
      font-size: 0.95rem; font-weight: 600; color: var(--brand-blue); 
      padding-top: 16px; border-top: 1px solid var(--border); 
    }

    .scope-box { 
      display: flex; align-items: center; justify-content: center; 
      gap: 32px; padding: 32px; background: var(--brand-light); 
      border-radius: 16px; margin-top: 48px; flex-wrap: wrap; 
    }
    .scope-stat { 
      font-family: 'Fraunces', serif; font-size: 2.5rem; 
      font-weight: 700; color: var(--brand-blue); 
    }
    .scope-text { 
      font-size: 0.9rem; color: var(--slate); 
      text-transform: uppercase; letter-spacing: 1px; 
      font-weight: 600; 
    }
    .scope-divider { font-size: 1.5rem; color: var(--border); }

    /* Case Study */
    .case-study-section { background: var(--warm-white); border-radius: 24px; padding: 60px 32px; }
    .case-study { 
      background: var(--white); border: 2px solid var(--border); 
      border-radius: 24px; padding: 40px; max-width: 800px; 
      margin: 0 auto; 
    }

    .case-study-header { 
      margin-bottom: 32px; padding-bottom: 24px; 
      border-bottom: 2px solid var(--border); 
    }
    .case-firm { 
      font-family: 'Fraunces', serif; font-size: 1.8rem; 
      font-weight: 600; color: var(--ink); margin-bottom: 8px; 
    }
    .case-meta { font-size: 0.9rem; color: var(--slate); }

    .case-results { 
      display: flex; align-items: center; justify-content: center; 
      gap: 32px; padding: 32px; background: var(--warm-white); 
      border-radius: 16px; margin-bottom: 24px; flex-wrap: wrap; 
    }
    .case-before, .case-after { text-align: center; }
    .case-label { 
      font-size: 0.75rem; text-transform: uppercase; 
      letter-spacing: 1.5px; color: var(--slate-light); 
      margin-bottom: 8px; font-weight: 600; 
    }
    .case-value { 
      font-family: 'Fraunces', serif; font-size: 2.5rem; 
      font-weight: 700; color: var(--success); margin-bottom: 4px; 
    }
    .case-detail { font-size: 0.9rem; color: var(--slate); }
    .case-arrow { font-size: 2rem; color: var(--success); font-weight: 700; }

    .case-timeline { 
      display: flex; flex-direction: column; gap: 12px; 
      margin: 24px 0; 
    }
    .case-week { 
      font-size: 0.95rem; color: var(--slate); 
      padding-left: 24px; position: relative; line-height: 1.7; 
    }
    .case-week::before { 
      content: '→'; position: absolute; left: 0; 
      color: var(--success); font-weight: 700; 
    }
    .case-week strong { color: var(--ink); }

    .case-quote { 
      margin-top: 24px; padding: 24px; background: var(--brand-light); 
      border-left: 4px solid var(--brand-blue); border-radius: 12px; 
      font-style: italic; font-size: 1.05rem; color: var(--ink); 
      line-height: 1.7; 
    }
    .case-attribution { 
      margin-top: 12px; font-style: normal; font-size: 0.9rem; 
      color: var(--slate); font-weight: 600; 
    }

    /* CTA Section */
    .cta-section { 
      background: linear-gradient(135deg, var(--ink), #1e293b); 
      border-radius: 24px; padding: 60px 32px; 
      text-align: center; color: white; margin: 80px 0; 
    }

    .cta-content { max-width: 700px; margin: 0 auto; }
    .cta-title { 
      font-family: 'Fraunces', serif; 
      font-size: clamp(2rem, 5vw, 2.8rem); 
      margin-bottom: 20px; 
    }
    .cta-subtitle { 
      font-size: 1.1rem; opacity: 0.9; 
      margin-bottom: 40px; line-height: 1.7; 
    }

    .cta-timeline { 
      display: grid; grid-template-columns: repeat(2, 1fr); 
      gap: 16px; margin: 32px 0; 
    }
    @media (max-width: 600px) { .cta-timeline { grid-template-columns: 1fr; } }
    .cta-step { 
      background: rgba(255,255,255,0.05); padding: 16px; 
      border-radius: 12px; font-size: 0.95rem; 
      text-align: left; 
    }
    .cta-step strong { color: white; }

    .btn-cta { 
      display: inline-flex; align-items: center; gap: 12px; 
      padding: 18px 40px; background: white; color: var(--ink); 
      font-size: 1.1rem; font-weight: 700; border-radius: 100px; 
      text-decoration: none; margin: 32px 0; 
      transition: all 0.3s var(--ease); 
    }
    .btn-cta:hover { 
      transform: translateY(-3px); 
      box-shadow: 0 20px 40px rgba(0,0,0,0.3); 
    }

    .cta-note { 
      font-size: 0.95rem; opacity: 0.8; margin-top: 20px; 
    }

    .cta-urgency { 
      margin-top: 32px; padding-top: 32px; 
      border-top: 1px solid rgba(255,255,255,0.1); 
      font-size: 0.9rem; opacity: 0.7; 
    }

    /* Footer */
    .footer { 
      padding: 40px 0; border-top: 2px solid var(--border); 
    }
    .footer-content { 
      display: flex; justify-content: space-between; 
      align-items: center; flex-wrap: wrap; gap: 24px; 
    }
    .footer-brand { display: flex; align-items: center; gap: 12px; }
    .logo-small { 
      width: 40px; height: 40px; background: var(--brand-blue); 
      border-radius: 10px; display: flex; align-items: center; 
      justify-content: center; font-family: 'Fraunces', serif; 
      font-size: 14px; font-weight: 600; color: white; 
    }
    .footer-name { 
      font-family: 'Fraunces', serif; font-size: 1.1rem; 
      font-weight: 500; color: var(--ink); 
    }
    .footer-tagline { 
      font-size: 0.7rem; color: var(--slate); 
      text-transform: uppercase; letter-spacing: 1px; 
    }
    .footer-contact { font-size: 0.9rem; color: var(--slate); }
    .footer-contact a { 
      color: var(--brand-blue); text-decoration: none; font-weight: 600; 
    }

    @media (max-width: 768px) {
      .hero-stats-grid { grid-template-columns: repeat(2, 1fr); }
      .findings-grid { grid-template-columns: 1fr; }
      .solutions-grid { grid-template-columns: 1fr; }
      .proof-grid { grid-template-columns: 1fr; }
      .case-results { flex-direction: column; }
      .footer-content { flex-direction: column; text-align: center; }
    }
  </style>`;
}

function getJavaScript() {
  return `<script>
    // Scroll progress
    window.addEventListener('scroll', () => {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      const scrolled = window.scrollY;
      const progress = (scrolled / scrollable) * 100;
      document.querySelector('.scroll-indicator').style.width = progress + '%';
    });

    // Reveal on scroll
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.finding-card, .solution-card, .case-study').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      el.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)';
      observer.observe(el);
    });
  </script>`;
}

// CLI
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: ./report-generator-v7.js <research.json> <ProspectName>');
    console.error('Example: ./report-generator-v7.js research.json "John Smith"');
    process.exit(1);
  }
  
  const researchFile = args[0];
  const prospectName = args[1];
  
  try {
    const researchData = JSON.parse(fs.readFileSync(researchFile, 'utf8'));
    const html = generateReport(researchData, prospectName);
    
    const outputDir = path.dirname(researchFile);
    const outputFile = path.join(outputDir, `${researchData.firmName.replace(/[^a-z0-9]/gi, '-').toLowerCase()}-report-v7.html`);
    
    fs.writeFileSync(outputFile, html);
    
    console.log(`✅ Report generated: ${outputFile}`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

module.exports = { generateReport };
